// Marcus King
// 5/5/2022
// CIS 1202.501

// Description: This is a program that is meant to assist calculations and recordkeeping for roleplaying games.
// Right now it is set up to demonstrate some of the capabilities with an example combat scenario between two npcs (non player characters)

// To use follow the promts to customize your character, than select a weapon to use, and finally which opponent to face.

// The program will generate a simulated battle, logging each hit and miss, along with damage dealt untill there is a winner.


#include <iostream>             // files
#include <string>
#include "Enums.h"
//#include "Creature.h"
//#include "Weapon.h"
#include "Character.h"



int diceRoll(int level);                                                                    //main functions
bool skillVsSkill(int aLevel, int tLevel);
bool skillCheck(int sLevel, int cLevel);
void attackVsAttack(Creature* c1, Creature* c2, Attack* a1, Attack* a2, range r);
void attackVsEvade(Creature* c1, Creature* c2, Attack* a1, range r);
int getMenu();

int main()																					//main
{
	srand(time(NULL));																		//seed random

	Character Knight("Sir Gawain", 1, 4, 6, 5, 6, 4, 2, weapons::sword);					// generate example npcs
	
	Character Pirate("Blackbeard", 0, 5, 7, 6, 6, 6, 0, weapons::sword);

	std::string playerName;
	int armor = 0, grapple = 4, melee = 4, initiative = 4, constitution = 4, evasion = 4, armorPenalty = 0, points = 10;		//store input for player character
	weapons weapon = weapons::knife;

	std::cout << "Enter Name" << '\n';																							// get player character name
	std::getline(std::cin, playerName, '\n');

	while (points > 0)																											// point buy skills
	{
		std::cout << "Remaining points: " << points << '\n' << '\n';
		std::cout << "1. armor: " << armor << '\n';
		std::cout << "2. grapple: " << grapple << '\n';
		std::cout << "3. melee: " << melee << '\n';
		std::cout << "4. initiative: " << initiative << '\n';
		std::cout << "5. constitution: " << constitution << '\n';
		std::cout << "6. evasion: " << evasion << '\n';
		int selection;

		std::cin >> selection;
		while (!std::cin.good() || selection < 1 || selection > 6)
		{
			std::cout << "Invalid input. Please try again" << '\n';
			std::cin.clear();
			std::cin.ignore(INT_MAX, '\n');
			std::cin >> selection;
		}

		switch (selection)
		{
		case 1:
		{
			if (points >= 4)
			{
				armor++;
				armorPenalty = armor / 2;
				points -= 4;
			}
			else
			{
				std::cout << "not enough points" << '\n';
			}
			break;
		}
		case 2:
		{
			grapple++;
			points--;
			break;
		}
		case 3:
		{
			melee++;
			points--;
			break;
		}
		case 4:
		{
			initiative++;
			points--;
			break;
		}
		case 5:
		{
			constitution++;
			points--;
			break;
		}
		case 6:
		{
			evasion++;
			points--;
			break;
		}
			
		}
	}

	std::cout << "Choose your weapon" << '\n';															// choose weapon
	std::cout << "1. Knife" << '\n';
	std::cout << "2. Sword" << '\n';
	std::cout << "3. Spear" << '\n';
	int selection;

	std::cin >> selection;
	while (!std::cin.good() || selection < 1 || selection > 6)
	{
		std::cout << "Invalid input. Please try again" << '\n';
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');
		std::cin >> selection;
	}

	switch (selection)
	{
	case 1:
	{
		weapon = weapons::knife;
		break;
	}
	case 2:
	{
		weapon = weapons::sword;
		break;
	}
	case 3:
	{
		weapon = weapons::spear;
		break;
	}
	}

	Character Player(playerName, armor, grapple, melee, initiative, constitution, evasion, armorPenalty, weapon);   // generate player character
	
	Character Oponent;

	std::cout << "Choose your oponent" << '\n';																		// choose oponent character
	std::cout << "1. Knight" << '\n';
	std::cout << "2. Pirate" << '\n';
	

	std::cin >> selection;
	while (!std::cin.good() || selection < 1 || selection > 2)
	{
		std::cout << "Invalid input. Please try again" << '\n';
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');
		std::cin >> selection;
	}

	switch (selection)
	{
	case 1:
	{
		Oponent = Knight;
		break;
	}
	case 2:
	{
		Oponent = Pirate;
		break;
	}
	default:
		Oponent = Knight;
	}

	if (getMenu() == 1)																											// battle simulation
	{
		if (skillVsSkill(Player.getSkillLevel(skill::S_initiative), Oponent.getSkillLevel(skill::S_initiative)) == true)   // initiative determines who strikes first
		{
			while (Player.getWoundLevel() < 8 && Oponent.getWoundLevel() < 8)
			{
				attackVsAttack(&Player, &Oponent, &Player.w1.a1, &Oponent.w1.a1, range::meleeR);							// this is a head to head attack, where either character could wound the other

				if (Player.getWoundLevel() < 8 && Oponent.getWoundLevel() < 8)
				{
					attackVsEvade(&Player, &Oponent, &Player.w1.a1, range::meleeR);											// these attacks can be evaded using the evasion skill but evading does no counter attack

					if (Player.getWoundLevel() < 8 && Oponent.getWoundLevel() < 8)
					{
						attackVsEvade(&Oponent, &Player, &Oponent.w1.a1, range::meleeR);
					}
				}
			}
			if (Player.getWoundLevel() > Oponent.getWoundLevel())
			{
				std::cout << Player.getChName() << " was slain." << '\n';
				std::cout << Oponent.getChName() << " is victorious!" << '\n';
			}
			else
			{
				std::cout << Oponent.getChName() << " was slain." << '\n';
				std::cout << Player.getChName() << " is victorious!" << '\n';
			}
		}
		else
		{																												// if the oponent rolls higher on initiative
			while (Player.getWoundLevel() < 8 && Oponent.getWoundLevel() < 8)
			{
				attackVsAttack(&Oponent, &Player, &Oponent.w1.a1, &Player.w1.a1, range::meleeR);

				if (Player.getWoundLevel() < 8 && Oponent.getWoundLevel() < 8)
				{
					attackVsEvade(&Oponent, &Player, &Oponent.w1.a1, range::meleeR);

					if (Player.getWoundLevel() < 8 && Oponent.getWoundLevel() < 8)
					{
						attackVsEvade(&Player, &Oponent, &Player.w1.a1, range::meleeR);
					}
				}
			}
			if (Player.getWoundLevel() > Oponent.getWoundLevel())
			{
				std::cout << Player.getChName() << " was slain." << '\n';
				std::cout << Oponent.getChName() << " is victorious!" << '\n';
			}
			else
			{
				std::cout << Oponent.getChName() << " was slain." << '\n';
				std::cout << Player.getChName() << " is victorious!" << '\n';
			}
		}
	}

}

int diceRoll(int level)																				// accepts a level and generate random number based on it (higher is better)
{	
	if (level <= 0)
	{
		return 0;
	}
	if (level % 2 == 0)
	{
		return (rand() % level + 1) + (rand() % level + 1);
	}
	else
	{
		return (rand() % (level + 0) + 1) + (rand() % (level + 1) + 1);
	}
}

bool skillVsSkill(int aLevel, int tLevel)														// compares two skill rolls and returns true if first parameter is higher
{
	int aResult = 0;
	int tResult = 0;

	while (aResult == tResult)
	{
		aResult = diceRoll(aLevel);
		tResult = diceRoll(tLevel);
	}
	
	if (aResult > tResult)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool skillCheck(int sLevel, int cLevel)																		// rolls against a static challenge level, returns true if succesful (higher)
{
	if (diceRoll(sLevel) >= cLevel)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void attackVsAttack(Creature* c1, Creature* c2, Attack* a1, Attack* a2, range r)							// calculates attacks and prints results
{
	int c1Wounds = c1->getWoundLevel();
	int c2Wounds = c2->getWoundLevel();
	switch (r)
	{
	case range::grappleR:
	{
		if (diceRoll(a1->grappleAttack(c1)) >= diceRoll(a2->grappleAttack(c2)))
		{
			a1->inflictDamage(c2);
			std::cout << c1->getName() << " hit " << c2->getName() << " for " << (c2->getWoundLevel() - c2Wounds) << '\n';
		}
		else
		{
			a2->inflictDamage(c1);
			std::cout << c2->getName() << " hit " << c1->getName() << " for " << (c1->getWoundLevel() - c1Wounds) << '\n';
		}

		break;
	}
	case range::meleeR:
	{
		if (diceRoll(a1->meleeAttack(c1)) >= diceRoll(a2->meleeAttack(c2)))
		{
			a1->inflictDamage(c2);
			std::cout << c1->getName() << " hit " << c2->getName() << " for " << (c2->getWoundLevel() - c2Wounds) << '\n';
		}
		else
		{
			a2->meleeAttack(c1);
			std::cout << c2->getName() << " hit " << c1->getName() << " for " << (c1->getWoundLevel() - c1Wounds) << '\n';
		}
		break;
	}
	default:
	{
		std::cout << "Error: out of range" << '\n';
		break;
	}
	}
}

void attackVsEvade(Creature* c1, Creature* c2, Attack* a1, range r)																		// calculates attacks against evasion
{
	int c2Wounds = c2->getWoundLevel();

	switch (r)
	{
	case range::grappleR:
	{
		if (diceRoll(a1->grappleAttack(c1)) >= diceRoll(c2->getSkillLevel(skill::S_evasion) + c2->getSkillLevel(skill::S_grapple) - 3))
		{
			a1->inflictDamage(c2);
			std::cout << c1->getName() << " hit " << c2->getName() << " for " << (c2->getWoundLevel() - c2Wounds) << '\n';
		}
		else
		{
			std::cout << c1->getName() << " missed " << c2->getName() << '\n';
		}

		break;
	}
	case range::meleeR:
	{
		if (diceRoll(a1->meleeAttack(c1)) >= diceRoll(c2->getSkillLevel(skill::S_evasion) + c2->getSkillLevel(skill::S_melee) - 3))
		{
			a1->inflictDamage(c2);
			std::cout << c1->getName() << " hit " << c2->getName() << " for " << (c2->getWoundLevel() - c2Wounds) << '\n';
		}
		else
		{
			std::cout << c1->getName() << " missed " << c2->getName() << '\n';
		}
		break;
	}
	default:
	{
		std::cout << "Error: out of range" << '\n';
		break;
	}
	}
}

int getMenu()																												//displays proceed menu
{
	std::cout << "1. Proceed to combat" << '\n';
	std::cout << "2. exit program" << '\n';

	int selection;

	std::cin >> selection;

	while (!std::cin.good() || selection < 0 || selection > 2)
	{
		std::cout << "Invalid input. Please try again" << '\n';
		std::cin.clear();
		std::cin.ignore(INT_MAX, '\n');
		std::cin >> selection;
	}

	return selection;
}

