#include "Attack.h"

Attack::Attack(std::string n, damageType dmgType, int baseDmg, int dmgModifier, int grappleB, int meleeB)
{
	name = n;
	dt = dmgType;
	baseDamage = baseDmg;
	damageModifier = dmgModifier;
	grappleBonus = grappleB;
	meleeBonus = meleeB;
}
Attack::Attack()
{
	name = "";
	dt = damageType::blunt;
	baseDamage = 4;
	damageModifier = 0;
	grappleBonus = 2;
	meleeBonus = 1;
}

void Attack::setAttack(std::string n, damageType dmgType, int baseDmg, int dmgModifier, int grappleB, int meleeB)
{
	name = n;
	dt = dmgType;
	baseDamage = baseDmg;
	damageModifier = dmgModifier;
	grappleBonus = grappleB;
	meleeBonus = meleeB;
}

void Attack::inflictDamage(Creature* target)
{
	target->takeDamage(dt, ((rand() % baseDamage + 1) + damageModifier));
}
int Attack::grappleAttack(Creature* attacker)
{
	return attacker->getSkillLevel(skill::S_grapple) + grappleBonus - attacker->getWoundLevel();
}
int Attack::meleeAttack(Creature* attacker)
{
	return attacker->getSkillLevel(skill::S_melee) + meleeBonus - attacker->getWoundLevel();
}

std::string Attack::getName()
{
	return name;
}
