#pragma once
#include <string>
#include "Enums.h"
#include "Attack.h"


class Weapon
{
protected:
	std::string weaponName = "";
	int maxLoaded = 0;
	int loadedAmmo = 0;
	int spareAmmo = 0;
	
public:
	Attack a1;
	Attack a2;
	Weapon(weapons weapon, std::string n);
	Weapon();
	std::string getName();
	int getMaxAmmo();
	int getLoadedAmmo();
	int getSpareAmmo();
	void spendAmmo();
	void reloadAll();
	void reloadOne();
	void setWeapon(weapons weapon, std::string n);
	
	
	
	
	
};

