#pragma once
#include "Attack.h"
class DexRangedAttack :
    public Attack
{
	std::string name;
	damageType dt;
	int baseDamage;
	int damageModifier;
	int grappleBonus;
	int meleeBonus;
	int shortRangeBonus;
	int mediumRangeBonus;
	int longRangeBonus;
public:
	DexRangedAttack(std::string n, damageType dmgType, int baseDmg, int dmgModifier, int grappleB, int meleeB, int srb, int mrb, int lrb);
	void inflictDamage(Creature* target);

	int rangedAttack(Creature* attacker, range r);
};

