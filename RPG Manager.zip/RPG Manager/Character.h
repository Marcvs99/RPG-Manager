#pragma once
#include "Creature.h"
#include "Weapon.h"
class Character :
    public Creature, public Weapon
{
public:
	/*Character();
	Character(std::string n);*/
	Character(std::string n, int armor, int grp, int m, int i, int c, int ev, int ap, weapons weapon);
	Weapon w1;
	std::string getChName();
	Character();
};

