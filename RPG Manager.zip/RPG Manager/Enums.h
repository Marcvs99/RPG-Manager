#pragma once

//special data types used across the program

enum class damageType { blunt, cut, pierce, chop, ballistic };
enum class range { grappleR, meleeR, shortR, mediumR, longR };
enum class skill { S_grapple, S_melee, S_strenghtRanged, S_dexRanged, S_initiative, S_athletics, S_constitution, S_evasion };
enum class weapons { knife, sword, spear, bow, crossbow, pistol, rifle};
