#include "StrengthRangedAttack.h"

StrengthRangedAttack::StrengthRangedAttack(std::string n, damageType dmgType, int baseDmg, int dmgModifier, int grappleB, int meleeB, int srb, int mrb, int lrb)
{
	name = n;
	dt = dmgType;
	baseDamage = baseDmg;
	damageModifier = dmgModifier;
	grappleBonus = grappleB;
	meleeBonus = meleeB;
	shortRangeBonus = srb;
	mediumRangeBonus = mrb;
	longRangeBonus = lrb;
}
void StrengthRangedAttack::inflictDamage(Creature* target)
{
	target->takeDamage(dt, ((rand() % baseDamage + 1) + damageModifier));
}
int StrengthRangedAttack::rangedAttack(Creature* attacker, range r)
{
	switch (r)
	{
	case range::grappleR:
	{
		return attacker->getSkillLevel(skill::S_grapple) + grappleBonus - attacker->getWoundLevel();
		break;
	}
	case range::meleeR:
	{
		return attacker->getSkillLevel(skill::S_melee) + meleeBonus - attacker->getWoundLevel();
		break;
	}
	case range::shortR:
	{
		return attacker->getSkillLevel(skill::S_strenghtRanged) + shortRangeBonus - attacker->getWoundLevel();
		break;
	}
	case range::mediumR:
	{
		return attacker->getSkillLevel(skill::S_strenghtRanged) + mediumRangeBonus - attacker->getWoundLevel();
		break;
	}
	case range::longR:
	{
		return attacker->getSkillLevel(skill::S_strenghtRanged) + longRangeBonus - attacker->getWoundLevel();
		break;
	}
	default:
	{
		break;
	}
	}
}
