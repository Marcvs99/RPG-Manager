#include "Creature.h"

Creature::Creature()
{
	 woundLevel = 0;
	 bluntResistance = 0;
	 cutResistance = 0;
	 pierceResistance = 0;
	 chopResistance = 0;
	 grapple = 4;
	 melee = 4;
	 strenghtRanged = 4;
	 dexRanged = 4;
	 initiative = 4;
	 athletics = 4;
	 acrobatics = 4;
	 constitution = 4;
	 evasion = 4;
	 armorPenalty = 0;
	 name = "Generic Creature";
	 acted = 0;

	 setWeapon(w1, weapons::knife);
	 setWeapon(w2, weapons::sword);
	 setWeapon(w3, weapons::spear);
}

Creature::Creature(std::string n)
{
	woundLevel = 0;
	bluntResistance = 0;
	cutResistance = 0;
	pierceResistance = 0;
	chopResistance = 0;
	grapple = 4;
	melee = 4;
	strenghtRanged = 4;
	dexRanged = 4;
	initiative = 4;
	athletics = 4;
	acrobatics = 4;
	constitution = 4;
	evasion = 4;
	armorPenalty = 0;
	name = n;
	acted = false;

	setWeapon(w1, weapons::knife);
	setWeapon(w2, weapons::sword);
	setWeapon(w3, weapons::spear);
	
}

Creature::Creature(std::string n, int armor, int grp, int m, int i, int c, int ev, int ap, weapons weapon)
{
	woundLevel = 0;
	bluntResistance = armor;
	cutResistance = armor;
	pierceResistance = armor;
	chopResistance = armor;
	grapple = grp;
	melee = m;
	strenghtRanged = 4;
	dexRanged = 4;
	initiative = i;
	athletics = 4;
	acrobatics = 4;
	constitution = c;
	evasion = ev;
	armorPenalty = ap;
	name = n;
	acted = false;
	setWeapon(w1, weapon);
}

int Creature::getWoundLevel()
{
	return woundLevel;
}

int Creature::getResistance(damageType dt)
{
	switch (dt)
	{
	case damageType::blunt:
	{
		return bluntResistance;
		break;
	}
	case damageType::cut:
	{
		return cutResistance;
		break;
	}
	case damageType::pierce:
	{
		return pierceResistance;
		break;
	}
	case damageType::chop:
	{
		return chopResistance;
		break;
	}
	}

	return 0;
}

int Creature::getSkillLevel(skill s)
{
	switch (s)
	{
	case skill::S_grapple:
	{
		return grapple;
		break;
	}
	case skill::S_melee:
	{
		return melee;
		break;
	}
	case skill::S_strenghtRanged:
	{
		return strenghtRanged;
		break;
	}
	case skill::S_dexRanged:
	{
		return dexRanged;
		break;
	}
	case skill::S_initiative:
	{
		return initiative;
		break;
	}
	case skill::S_athletics:
	{
		return athletics;
		break;
	}
	case skill::S_constitution:
	{
		return constitution;
		break;
	}
	case skill::S_evasion:
	{
		return evasion;
		break;
	}

	}

	return 0;
}

std::string Creature::getName()
{
	return name;
}

bool Creature::getActed()
{
	return acted;
}

void Creature::wound(int damage)
{
	if (damage > 0)
	{
		woundLevel += damage;
	}
}

void Creature::heal()
{
	woundLevel = 0;
}

void Creature::act()
{
	acted = true;
}

void Creature::replenishAction()
{
	acted = false;
}

void Creature::takeDamage(damageType dt, int damage)
{
	if (diceRoll(getSkillLevel(skill::S_constitution)) > damage)
	{
		damage--;
	}
	wound(damage - getResistance(dt));
}

void Creature::displayInfo()
{
	std::cout << "Name: " << getName() << '\n';
}

void Creature::setWeapon(weapons& w, weapons nw)
{
	w = nw;
}

weapons Creature::getWeapon(int num)
{
	switch (num)
	{
	case 0:
	{
		return w1;
		break;
	}
	case 1:
	{
		return w2;
		break;
	}
	case 3:
	{
		return w3;
		break;
	}
	}
}

int Creature::diceRoll(int level)
{
	if (level <= 0)
	{
		return 0;
	}
	if (level % 2 == 0)
	{
		return (rand() % level + 1) + (rand() % level + 1);
	}
	else
	{
		return (rand() % (level + 0) + 1) + (rand() % (level + 1) + 1);
	}
}

