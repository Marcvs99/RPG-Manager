#pragma once
#include <iostream>
#include "Enums.h"
//#include "Weapon.h"


class Creature
{
protected:
	int woundLevel;
	int bluntResistance;
	int cutResistance;
	int pierceResistance;
	int chopResistance;
	int grapple;
	int melee;
	int strenghtRanged;
	int dexRanged;
	int initiative;
	int athletics;
	int acrobatics;
	int constitution;
	int evasion;
	int armorPenalty;
	std::string name;
	bool acted;
	weapons w1;
	weapons w2;
	weapons w3;
	

public:
	
	Creature();
	Creature(std::string n);
	Creature(std::string n, int armor, int grp, int m, int i, int c, int ev, int ap, weapons weapon);
	int getWoundLevel();
	int getResistance(damageType dt);
	int getSkillLevel(skill s);
	std::string getName();
	bool getActed();
	void wound(int damage);
	void heal();
	void act();
	void replenishAction();
	void takeDamage(damageType dt, int damage);
	void displayInfo();
	void setWeapon(weapons& w, weapons nw);
	weapons getWeapon(int num);
	int diceRoll(int level);
	
	
};

