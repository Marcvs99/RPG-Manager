#include "Weapon.h"

Weapon::Weapon()
{
	weaponName = "";
	maxLoaded = 0;
	loadedAmmo = 0;
	spareAmmo = 0;
}

Weapon::Weapon(weapons weapon, std::string n)
{
	weaponName = n;
	maxLoaded = 0;
	loadedAmmo = 0;
	spareAmmo = 0;

	switch (weapon)
	{
	case weapons::knife:
	{
		a1.setAttack("slash", damageType::cut, 4, 1, 0, 1);
		a2.setAttack("jab", damageType::pierce, 4, 1, 0, 1);
		break;
	}
	case weapons::sword:
	{
		a1.setAttack("slash", damageType::cut, 4, 1, -3, 2);
		a2.setAttack("jab", damageType::pierce, 4, 1, -6, 2);
		break;
	}
	case weapons::spear:
	{
		a1.setAttack("jab", damageType::pierce, 4, 1, -20, 3);
		a2.setAttack("jab", damageType::pierce, 4, 1, -20, 3);
		break;
	}
	case weapons::bow:
	{
		break;
	}
	case weapons::crossbow:
	{
		break;
	}
	case weapons::pistol:
	{
		break;
	}
	case weapons::rifle:
	{
		break;
	}
	default:
	{
		a1.setAttack("slash", damageType::cut, 4, 1, 0, 1);
		a2.setAttack("jab", damageType::pierce, 4, 1, 0, 1);
	}
	}
}

void Weapon::setWeapon(weapons weapon, std::string n)
{
	weaponName = n;
	maxLoaded = 0;
	loadedAmmo = 0;
	spareAmmo = 0;

	switch (weapon)
	{
	case weapons::knife:
	{
		a1.setAttack("slash", damageType::cut, 4, 1, 0, 1);
		a2.setAttack("jab", damageType::pierce, 4, 1, 0, 1);
		break;
	}
	case weapons::sword:
	{
		a1.setAttack("slash", damageType::cut, 4, 1, -3, 2);
		a2.setAttack("jab", damageType::pierce, 4, 1, -6, 2);
		break;
	}
	case weapons::spear:
	{
		a1.setAttack("jab", damageType::pierce, 4, 1, -20, 3);
		a2.setAttack("jab", damageType::pierce, 4, 1, -20, 3);
		break;
	}
	case weapons::bow:
	{
		break;
	}
	case weapons::crossbow:
	{
		break;
	}
	case weapons::pistol:
	{
		break;
	}
	case weapons::rifle:
	{
		break;
	}
	default:
	{
		a1.setAttack("slash", damageType::cut, 4, 1, 0, 1);
		a2.setAttack("jab", damageType::pierce, 4, 1, 0, 1);
	}
	}
}

std::string Weapon::getName()
{
	return weaponName;
}

int Weapon::getMaxAmmo()
{
	return maxLoaded;
}

int Weapon::getLoadedAmmo()
{
	return loadedAmmo;
}

int Weapon::getSpareAmmo()
{
	return spareAmmo;
}

void Weapon::spendAmmo()
{
	loadedAmmo--;
}

void Weapon::reloadAll()
{
	if (spareAmmo >= maxLoaded)
	{
		spareAmmo -= maxLoaded - loadedAmmo;
		loadedAmmo = maxLoaded;
	}
	else
	{
		loadedAmmo += spareAmmo;
		spareAmmo = 0;
	}
}

void Weapon::reloadOne()
{
	if (spareAmmo > 0 && (loadedAmmo != maxLoaded))
	{
		loadedAmmo ++;
	}
}
