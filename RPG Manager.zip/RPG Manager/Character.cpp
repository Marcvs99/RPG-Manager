#include "Character.h"

//Character::Character()
//{
//
//}
//Character::Character(std::string n)
//{
//
//}
Character::Character(std::string n, int armor, int grp, int m, int i, int c, int ev, int ap, weapons weapon)
{
	woundLevel = 0;
	bluntResistance = armor;
	cutResistance = armor;
	pierceResistance = armor;
	chopResistance = armor;
	grapple = grp;
	melee = m;
	strenghtRanged = 4;
	dexRanged = 4;
	initiative = i;
	athletics = 4;
	acrobatics = 4;
	constitution = c;
	evasion = ev;
	armorPenalty = ap;
	name = n;
	acted = false;
	w1.setWeapon(weapon, n);
}

std::string Character::getChName()
{
	return Creature::name;
}

Character::Character()
{

}