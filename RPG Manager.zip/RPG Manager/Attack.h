#pragma once
#include <string>
#include "Enums.h"
#include "Creature.h"


class Attack
{
	std::string name;
	damageType dt;
	int baseDamage;
	int damageModifier;
	int grappleBonus;
	int meleeBonus;
public:
	Attack(std::string n, damageType dmgType, int baseDmg, int dmgModifier, int grappleB, int meleeB);
	Attack();
	void inflictDamage(Creature* target);
	int grappleAttack(Creature* attacker);
	int meleeAttack(Creature* attacker);
	std::string getName();
	void setAttack(std::string n, damageType dmgType, int baseDmg, int dmgModifier, int grappleB, int meleeB);
};

